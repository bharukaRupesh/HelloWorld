package com.sample.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sample.bean.UserBean;

@Repository
public interface UserRepository extends CrudRepository<UserBean, Integer> {

	@Query("FROM UserBean WHERE username = :username")
	public UserBean findUserByUsername(@Param("username") String username);

}
