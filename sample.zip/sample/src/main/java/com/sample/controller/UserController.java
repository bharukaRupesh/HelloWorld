package com.sample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sample.bean.UserBean;
import com.sample.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping(path = "/login")
	public ModelAndView login() {

		ModelAndView modelAndView = null;

		modelAndView = new ModelAndView();
		modelAndView.addObject("user", new UserBean());
		modelAndView.setViewName("login");
		return modelAndView;
	}

	@PostMapping(path = "/login")
	public ModelAndView login(String username, String password) {

		ModelAndView modelAndView = null;
		boolean status = false;
		status = userService.login(username, password);
		modelAndView = new ModelAndView();
		if (status) {
			modelAndView.setViewName("home");
		} else {
			modelAndView.addObject("message", "Username or password is invalid..!!");
			modelAndView.addObject("user", new UserBean());
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}
}
